# <div align="center">Coffee House Project</div>
 <div align="center">Utilizing a Datbase and establishing a shopping cart</div>
 
 ![Figure 1](https://github.com/Chester2171/NightSightsCoffeeRoaster/blob/master/Wireframe/Database%20Displayed.PNG)
 
 ![Figure 2](https://github.com/Chester2171/NightSightsCoffeeRoaster/blob/master/Wireframe/Database.PNG)
 
 ![Figure 3](https://github.com/Chester2171/NightSightsCoffeeRoaster/blob/master/Wireframe/Form.PNG)
 
 ![Figure 5](https://github.com/Chester2171/NightSightsCoffeeRoaster/blob/master/Wireframe/Form2.PNG)
 
 ![Figure 6](https://github.com/Chester2171/NightSightsCoffeeRoaster/blob/master/Wireframe/Orders.PNG)
 
